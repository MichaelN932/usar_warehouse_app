# Warehouse Inventory & PPE Management System
## Technical Specification for Claude Code

---

## Overview

Build a React TypeScript PWA for warehouse inventory management and PPE issuance tracking. The system serves a fire department's USAR Task Force, allowing team members to request equipment and warehouse staff to fulfill those requests.

---

## Tech Stack

- **Frontend**: React 18+ with TypeScript
- **Styling**: Tailwind CSS
- **State Management**: React Context or Zustand
- **Routing**: React Router v6
- **Backend**: Node.js/Express API (or Azure Functions)
- **Database**: Azure SQL Server (schema provided in schema.sql)
- **Authentication**: Azure Entra ID (M365 integration) or email/password
- **PWA**: Workbox for service worker, offline support
- **Mobile**: Capacitor for iOS/Android deployment
- **OCR**: Azure AI Document Intelligence API
- **Email**: SendGrid or Azure Communication Services
- **Push Notifications**: Web Push API

---

## User Roles

### Team Member
- Request items from catalog
- View personal issued inventory (durables)
- View order history (all requests)
- Check request status
- Acknowledge receipt with digital signature
- Update personal size preferences

### Warehouse Staff (includes all Team Member capabilities)
- View and fulfill request queue
- Mark items as backordered
- Manage inventory counts
- Receive purchase orders
- Use barcode scanner for item lookup
- Use OCR to capture receiving documents
- Create requests on behalf of other users

### Warehouse Admin (includes all Warehouse Staff capabilities)
- Generate reports
- Manage users (create, edit, deactivate)
- Manage item catalog (categories, item types, variants, sizes)
- Manage vendors
- View audit trail
- Configure system settings (par levels, notification templates)

---

## Core Business Rules

### Item Requesting
1. Items are categorized: Category → Item Type → Variant → Size
2. **Consumables**: Can be requested anytime without justification
3. **Durables**: If user already has one issued (not returned), require replacement reason (Damaged, Lost, Sizing Issue, etc.)
4. User can optionally specify a variant preference; warehouse can substitute if unavailable
5. User's stored size preferences should pre-fill the request form but not block submission

### Request Fulfillment Flow
1. Request submitted → Status: "Pending"
2. Warehouse reviews → Either:
   - Fulfill: Select specific variant/size from stock → Status: "ReadyForPickup"
   - Backorder: Item not in stock → Status: "Backordered" → Request stays in queue
3. User picks up → Signs on device → Status: "Fulfilled"
4. Issued items added to user's IssuedInventory

### Backorder Flow
1. Request line marked as backordered
2. When inventory is updated (receiving, adjustment), system checks backorder queue
3. If stock now available for backordered item → Notification sent to warehouse staff
4. Warehouse fulfills backordered item → Normal pickup flow

### Inventory Updates
- Receiving: Match against open PO, update stock
- Manual adjustment: Count discrepancies, damage, loss
- Issuance: Reduce stock when items fulfilled
- Returns: Increase stock when durables returned (if serviceable)

### Par Levels vs FEMA Requirements
- **FEMARequiredQty**: Reference field showing what the FEMA Cache List recommends (read-only reference)
- **ParLevel**: Your warehouse's actual reorder point (set by Warehouse Admin)
- Low stock alerts trigger when inventory falls below ParLevel (not FEMA qty)
- Reports can compare current stock vs FEMA requirements for compliance visibility

---

## Screen Specifications

### All Users

#### Login Screen
- M365/Entra ID sign-in button (preferred)
- Or email/password fallback
- "Remember me" option
- PWA install prompt

#### Dashboard (role-based)
- Team Member: Quick request button, pending requests count, recent activity
- Warehouse Staff: Above + fulfillment queue count, low stock alerts
- Admin: Above + system stats, user count

#### Navigation
- Bottom nav on mobile (4-5 icons max)
- Side nav on desktop
- Role-based menu items

---

### Team Member Screens

#### Request Items
1. Category grid/list
2. Select Item Type → Show if consumable/durable
3. Select Size (pre-filled from profile if available)
4. Optional: Select variant preference or "No Preference"
5. Quantity selector
6. If durable and user already has one → Show reason dropdown (required)
7. Add to cart or submit immediately
8. Review cart → Submit request
9. Confirmation with request number

#### My Requests
- List of all requests with status badges
- Filter by status
- Tap to expand details
- Show individual line items and their status

#### My Inventory
- List of currently issued durable items
- Item name, variant, size, issued date
- Option to request replacement (pre-fills reason form)

#### My Profile
- View/edit size preferences (shirt, pants waist/inseam, boots, gloves, hat)
- Notification preferences (push, email)
- View issuance history

#### Pickup Signature
- Called when request status is "ReadyForPickup"
- Show items to be received
- Signature canvas
- Submit → Updates status to "Fulfilled"

---

### Warehouse Staff Screens

#### Fulfillment Queue
- List of pending requests, sorted by date (oldest first)
- Each card shows: Requester name, item count, date, priority indicator
- Tap to expand → Show line items
- For each line:
  - Show requested item type, size, quantity, variant preference
  - Dropdown to select actual variant/size to issue (from available stock)
  - "Fulfill" button or "Backorder" button
- Bulk fulfill option for entire request

#### Inventory Management
- Search/browse items by category, type, variant
- Barcode scanner button → Opens camera, scans barcode, navigates to item
- For each size: Show quantity on hand, reserved, available
- Quick adjust: +/- buttons for count corrections
- Full adjustment form: Reason dropdown, notes

#### Receive Orders
- List of open POs (Status: Submitted, PartialReceived)
- Tap PO → Show line items with ordered vs received quantities
- OCR capture button:
  1. Opens camera
  2. Capture packing slip image
  3. Send to Azure Document Intelligence
  4. Parse results → Pre-fill received quantities
  5. User confirms/adjusts
  6. Submit → Updates inventory, PO status

#### Create Request for User
- Search/select user
- Same request flow as Team Member
- Request shows "Created by [staff name] for [user name]"

---

### Admin Screens

#### User Management
- List all users with role badges
- Search by name/email
- Add new user: Name, email, role, initial password
- Edit user: Change role, update info, reset password
- Deactivate user (soft delete)

#### Item Catalog Management
- Tree view: Categories → Item Types → Variants → Sizes
- Add/edit/deactivate at each level
- For Item Types: Set consumable/durable, par level
- For Variants: Set SKU, barcode, unit cost
- Bulk import option (CSV)

#### Vendor Management
- List vendors
- Add/edit vendor: Name, contact, email, phone, address, notes
- View PO history per vendor

#### Purchase Orders
- Create new PO:
  1. Select vendor
  2. Add line items (select size, quantity, unit cost)
  3. Save as draft or submit
- Edit draft POs
- View PO history with status

#### Reports
- Inventory valuation (total cost of stock on hand)
- Issuance report by date range, user, or item
- Request fulfillment time metrics
- Low stock report
- User activity report
- Export to CSV/Excel

#### Audit Log Viewer
- Filterable list: Date range, user, table, action type
- Show before/after values for updates

---

## Offline Capability

### Must Work Offline
- View personal inventory
- View pending requests
- Browse item catalog (cached)
- Create new requests (queued for sync)
- View own profile

### Sync When Online
- Queue management with IndexedDB
- Background sync for queued actions
- Conflict resolution: Server wins, notify user of conflicts
- Visual indicator when offline
- Visual indicator when pending sync items exist

---

## Notifications

### Push Notifications
- Request status changed
- Ready for pickup
- Backorder fulfilled
- Low stock alert (warehouse staff/admin only)

### Email Notifications
- Ready for pickup
- Backorder fulfilled
- Low stock alert (warehouse staff/admin only)
- Weekly summary report (admin only)

---

## Barcode Scanning

- Use device camera via `navigator.mediaDevices`
- Library: `@zxing/browser` or `quagga2`
- Scan → Look up by Variants.Barcode field
- Navigate to item detail or add to current action

---

## Digital Signature

- Canvas-based signature capture
- Save as base64 PNG
- Store in Requests.PickupSignature
- Display in request history

---

## OCR Integration (Azure Document Intelligence)

### Flow
1. User taps "Scan Receiving Document"
2. Camera opens, user captures image
3. Image sent to Azure Document Intelligence API (prebuilt invoice/receipt model or custom)
4. Response parsed for:
   - Vendor name (match to existing vendor)
   - PO number (match to existing PO)
   - Line items with quantities
5. Pre-fill receiving form
6. User confirms/adjusts
7. Submit receiving

### API Integration
```typescript
// Example call structure
const endpoint = process.env.AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT;
const apiKey = process.env.AZURE_DOCUMENT_INTELLIGENCE_KEY;

// POST to analyze document
// Poll for results
// Parse response
```

---

## API Endpoints (REST)

### Auth
- POST /api/auth/login
- POST /api/auth/logout
- GET /api/auth/me
- POST /api/auth/refresh

### Users
- GET /api/users (admin)
- GET /api/users/:id
- POST /api/users (admin)
- PUT /api/users/:id
- PUT /api/users/:id/sizes (own profile or admin)

### Categories
- GET /api/categories
- POST /api/categories (admin)
- PUT /api/categories/:id (admin)

### Item Types
- GET /api/item-types
- GET /api/item-types/:id
- POST /api/item-types (admin)
- PUT /api/item-types/:id (admin)

### Variants
- GET /api/variants
- GET /api/variants/:id
- GET /api/variants/barcode/:barcode
- POST /api/variants (admin)
- PUT /api/variants/:id (admin)

### Sizes
- GET /api/sizes
- POST /api/sizes (admin)
- PUT /api/sizes/:id (admin)

### Inventory
- GET /api/inventory
- GET /api/inventory/:sizeId
- PUT /api/inventory/:sizeId (warehouse+)
- POST /api/inventory/adjust (warehouse+)

### Requests
- GET /api/requests (filtered by role)
- GET /api/requests/:id
- POST /api/requests
- PUT /api/requests/:id/fulfill (warehouse+)
- PUT /api/requests/:id/backorder (warehouse+)
- PUT /api/requests/:id/sign
- PUT /api/requests/:id/cancel

### Purchase Orders
- GET /api/purchase-orders (warehouse+)
- GET /api/purchase-orders/:id
- POST /api/purchase-orders (warehouse+)
- PUT /api/purchase-orders/:id (warehouse+)
- POST /api/purchase-orders/:id/receive (warehouse+)

### Vendors
- GET /api/vendors
- POST /api/vendors (admin)
- PUT /api/vendors/:id (admin)

### Notifications
- GET /api/notifications
- PUT /api/notifications/:id/read
- POST /api/push-subscriptions

### Reports (admin)
- GET /api/reports/inventory-valuation
- GET /api/reports/issuance?startDate=&endDate=
- GET /api/reports/low-stock
- GET /api/reports/audit-log

### OCR
- POST /api/ocr/analyze (multipart form data with image)

---

## Project Structure

```
/src
  /api            # API service functions
  /components     # Reusable UI components
    /ui           # Base components (Button, Input, Card, etc.)
    /forms        # Form components
    /layout       # Layout components (Nav, Header, etc.)
  /contexts       # React contexts (Auth, Theme, etc.)
  /hooks          # Custom hooks
  /pages          # Page components by role
    /auth
    /team-member
    /warehouse
    /admin
    /shared
  /services       # Business logic, API calls
  /types          # TypeScript interfaces
  /utils          # Helper functions
  /workers        # Service worker, background sync
  App.tsx
  main.tsx
  index.css

/server           # If building API in same repo
  /controllers
  /middleware
  /routes
  /services
  /db
  server.ts

/public
  manifest.json
  icons/
```

---

## Getting Started with Claude Code

### Phase 1: Foundation
1. Initialize React + TypeScript + Vite project
2. Configure Tailwind CSS
3. Set up project structure
4. Create base UI components
5. Set up React Router with auth guards

### Phase 2: Authentication
1. Create login page
2. Set up auth context
3. Implement role-based route protection
4. Add auth API integration

### Phase 3: Team Member Features
1. Dashboard
2. Item catalog browsing
3. Request creation flow
4. My Requests list
5. My Inventory view
6. Profile/sizes

### Phase 4: Warehouse Staff Features
1. Fulfillment queue
2. Fulfill/backorder actions
3. Inventory management
4. Barcode scanning
5. Receiving with OCR

### Phase 5: Admin Features
1. User management
2. Catalog management
3. Vendor management
4. Purchase orders
5. Reports
6. Audit log

### Phase 6: PWA & Offline
1. Service worker setup
2. Offline data caching
3. Background sync
4. Push notifications

### Phase 7: Polish
1. Error handling
2. Loading states
3. Responsive design refinement
4. Testing
5. Performance optimization

---

## Environment Variables

```env
VITE_API_URL=http://localhost:3001/api
VITE_AZURE_TENANT_ID=
VITE_AZURE_CLIENT_ID=
VITE_AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=
VITE_AZURE_DOCUMENT_INTELLIGENCE_KEY=
VITE_VAPID_PUBLIC_KEY=
```

---

## Database Connection (Server)

```env
DB_SERVER=your-server.database.windows.net
DB_NAME=warehouse_inventory
DB_USER=
DB_PASSWORD=
```

---

## Notes for Claude Code

- Use functional components with hooks
- Prefer composition over inheritance
- Use TypeScript strictly (no `any` unless absolutely necessary)
- Follow React best practices for performance (useMemo, useCallback where appropriate)
- Make components responsive (mobile-first)
- Include loading and error states for all async operations
- Use consistent naming conventions
- Add JSDoc comments for complex functions
- Structure forms with React Hook Form or similar
