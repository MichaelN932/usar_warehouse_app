-- =============================================
-- Warehouse Inventory & PPE Management System
-- SQL Schema for Azure SQL / SQL Server
-- =============================================

-- =============================================
-- USERS & AUTHENTICATION
-- =============================================

CREATE TABLE Roles (
    RoleId INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL UNIQUE,
    Description NVARCHAR(255),
    CreatedAt DATETIME2 DEFAULT GETUTCDATE()
);

INSERT INTO Roles (RoleName, Description) VALUES
('TeamMember', 'Can request items, view personal inventory, acknowledge receipt'),
('WarehouseStaff', 'Can fulfill requests, manage inventory, receive orders, scan barcodes'),
('WarehouseAdmin', 'Full access including reports, user management, system configuration');

CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Email NVARCHAR(255) NOT NULL UNIQUE,
    FirstName NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(100) NOT NULL,
    RoleId INT NOT NULL FOREIGN KEY REFERENCES Roles(RoleId),
    IsActive BIT DEFAULT 1,
    
    -- Size preferences (optional, for convenience)
    ShirtSize NVARCHAR(20),
    PantsWaist NVARCHAR(10),
    PantsInseam NVARCHAR(10),
    BootSize NVARCHAR(10),
    GloveSize NVARCHAR(20),
    HatSize NVARCHAR(20),
    
    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX IX_Users_Email ON Users(Email);
CREATE INDEX IX_Users_RoleId ON Users(RoleId);

-- =============================================
-- ITEM CATALOG (Category > ItemType > Variant > Size)
-- =============================================

CREATE TABLE Categories (
    CategoryId INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL UNIQUE,
    Description NVARCHAR(500),
    SortOrder INT DEFAULT 0,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETUTCDATE()
);

CREATE TABLE ItemTypes (
    ItemTypeId INT IDENTITY(1,1) PRIMARY KEY,
    CategoryId INT NOT NULL FOREIGN KEY REFERENCES Categories(CategoryId),
    ItemTypeName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500),
    FEMACode NVARCHAR(20),                -- FEMA Cache Item Number (e.g., LG-0112.00)
    FEMARequiredQty INT DEFAULT 0,        -- FEMA Cache List recommended quantity (reference only)
    IsConsumable BIT NOT NULL DEFAULT 0,  -- 0 = Durable, 1 = Consumable
    ParLevel INT DEFAULT 0,               -- Your warehouse's actual reorder point
    SortOrder INT DEFAULT 0,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
    
    CONSTRAINT UQ_ItemType_Category UNIQUE (CategoryId, ItemTypeName)
);

CREATE INDEX IX_ItemTypes_FEMACode ON ItemTypes(FEMACode);

CREATE INDEX IX_ItemTypes_CategoryId ON ItemTypes(CategoryId);

CREATE TABLE Variants (
    VariantId INT IDENTITY(1,1) PRIMARY KEY,
    ItemTypeId INT NOT NULL FOREIGN KEY REFERENCES ItemTypes(ItemTypeId),
    VariantName NVARCHAR(100) NOT NULL,   -- e.g., "5.11 Taclite Pro", "Propper BDU"
    SKU NVARCHAR(50),
    Description NVARCHAR(500),
    UnitCost DECIMAL(10,2) DEFAULT 0,
    Barcode NVARCHAR(100),
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
    
    CONSTRAINT UQ_Variant_ItemType UNIQUE (ItemTypeId, VariantName)
);

CREATE INDEX IX_Variants_ItemTypeId ON Variants(ItemTypeId);
CREATE INDEX IX_Variants_Barcode ON Variants(Barcode);

CREATE TABLE Sizes (
    SizeId INT IDENTITY(1,1) PRIMARY KEY,
    VariantId INT NOT NULL FOREIGN KEY REFERENCES Variants(VariantId),
    SizeName NVARCHAR(50) NOT NULL,       -- e.g., "32x32", "Large", "10.5"
    SortOrder INT DEFAULT 0,
    IsActive BIT DEFAULT 1,
    
    CONSTRAINT UQ_Size_Variant UNIQUE (VariantId, SizeName)
);

CREATE INDEX IX_Sizes_VariantId ON Sizes(VariantId);

-- =============================================
-- INVENTORY
-- =============================================

CREATE TABLE Inventory (
    InventoryId INT IDENTITY(1,1) PRIMARY KEY,
    SizeId INT NOT NULL FOREIGN KEY REFERENCES Sizes(SizeId),
    QuantityOnHand INT NOT NULL DEFAULT 0,
    QuantityReserved INT NOT NULL DEFAULT 0,  -- Reserved for pending requests
    LastCountDate DATETIME2,
    LastCountBy INT FOREIGN KEY REFERENCES Users(UserId),
    UpdatedAt DATETIME2 DEFAULT GETUTCDATE(),
    
    CONSTRAINT UQ_Inventory_Size UNIQUE (SizeId),
    CONSTRAINT CK_Inventory_Quantity CHECK (QuantityOnHand >= 0 AND QuantityReserved >= 0)
);

CREATE INDEX IX_Inventory_SizeId ON Inventory(SizeId);

-- =============================================
-- VENDORS & PURCHASE ORDERS
-- =============================================

CREATE TABLE Vendors (
    VendorId INT IDENTITY(1,1) PRIMARY KEY,
    VendorName NVARCHAR(200) NOT NULL,
    ContactName NVARCHAR(100),
    Email NVARCHAR(255),
    Phone NVARCHAR(50),
    Address NVARCHAR(500),
    Website NVARCHAR(255),
    Notes NVARCHAR(1000),
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 DEFAULT GETUTCDATE()
);

CREATE TABLE PurchaseOrders (
    PurchaseOrderId INT IDENTITY(1,1) PRIMARY KEY,
    PONumber NVARCHAR(50) NOT NULL UNIQUE,
    VendorId INT NOT NULL FOREIGN KEY REFERENCES Vendors(VendorId),
    Status NVARCHAR(50) NOT NULL DEFAULT 'Draft',  -- Draft, Submitted, PartialReceived, Received, Cancelled
    OrderDate DATETIME2,
    ExpectedDeliveryDate DATETIME2,
    TotalAmount DECIMAL(12,2) DEFAULT 0,
    Notes NVARCHAR(1000),
    CreatedBy INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX IX_PurchaseOrders_VendorId ON PurchaseOrders(VendorId);
CREATE INDEX IX_PurchaseOrders_Status ON PurchaseOrders(Status);
CREATE INDEX IX_PurchaseOrders_PONumber ON PurchaseOrders(PONumber);

CREATE TABLE PurchaseOrderLines (
    POLineId INT IDENTITY(1,1) PRIMARY KEY,
    PurchaseOrderId INT NOT NULL FOREIGN KEY REFERENCES PurchaseOrders(PurchaseOrderId) ON DELETE CASCADE,
    SizeId INT NOT NULL FOREIGN KEY REFERENCES Sizes(SizeId),
    QuantityOrdered INT NOT NULL,
    QuantityReceived INT NOT NULL DEFAULT 0,
    UnitCost DECIMAL(10,2) NOT NULL DEFAULT 0,
    LineTotal AS (QuantityOrdered * UnitCost) PERSISTED,
    
    CONSTRAINT CK_POLine_Quantity CHECK (QuantityOrdered > 0 AND QuantityReceived >= 0)
);

CREATE INDEX IX_POLines_PurchaseOrderId ON PurchaseOrderLines(PurchaseOrderId);

-- =============================================
-- RECEIVING (with OCR support)
-- =============================================

CREATE TABLE ReceivingDocuments (
    ReceivingDocId INT IDENTITY(1,1) PRIMARY KEY,
    PurchaseOrderId INT FOREIGN KEY REFERENCES PurchaseOrders(PurchaseOrderId),
    DocumentImageUrl NVARCHAR(500),       -- Stored image from OCR capture
    OCRRawText NVARCHAR(MAX),             -- Raw text extracted by OCR
    OCRProcessedAt DATETIME2,
    ReceivedBy INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
    ReceivedAt DATETIME2 DEFAULT GETUTCDATE(),
    Notes NVARCHAR(1000)
);

CREATE TABLE ReceivingLines (
    ReceivingLineId INT IDENTITY(1,1) PRIMARY KEY,
    ReceivingDocId INT NOT NULL FOREIGN KEY REFERENCES ReceivingDocuments(ReceivingDocId) ON DELETE CASCADE,
    POLineId INT FOREIGN KEY REFERENCES PurchaseOrderLines(POLineId),
    SizeId INT NOT NULL FOREIGN KEY REFERENCES Sizes(SizeId),
    QuantityReceived INT NOT NULL,
    
    CONSTRAINT CK_ReceivingLine_Quantity CHECK (QuantityReceived > 0)
);

-- =============================================
-- ITEM REQUESTS (Employee Store)
-- =============================================

CREATE TABLE Requests (
    RequestId INT IDENTITY(1,1) PRIMARY KEY,
    RequestedBy INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
    Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',  -- Pending, Approved, Backordered, ReadyForPickup, Fulfilled, Cancelled
    RequestDate DATETIME2 DEFAULT GETUTCDATE(),
    Notes NVARCHAR(1000),
    
    -- Fulfillment tracking
    FulfilledBy INT FOREIGN KEY REFERENCES Users(UserId),
    FulfilledAt DATETIME2,
    
    -- Pickup/signature tracking
    PickupSignature NVARCHAR(MAX),        -- Base64 signature image
    PickupSignedAt DATETIME2,
    PickupAcknowledgedBy INT FOREIGN KEY REFERENCES Users(UserId),
    
    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
    UpdatedAt DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX IX_Requests_RequestedBy ON Requests(RequestedBy);
CREATE INDEX IX_Requests_Status ON Requests(Status);
CREATE INDEX IX_Requests_RequestDate ON Requests(RequestDate);

CREATE TABLE RequestLines (
    RequestLineId INT IDENTITY(1,1) PRIMARY KEY,
    RequestId INT NOT NULL FOREIGN KEY REFERENCES Requests(RequestId) ON DELETE CASCADE,
    ItemTypeId INT NOT NULL FOREIGN KEY REFERENCES ItemTypes(ItemTypeId),
    RequestedSizeId INT FOREIGN KEY REFERENCES Sizes(SizeId),  -- Specific size if known
    PreferredVariantId INT FOREIGN KEY REFERENCES Variants(VariantId),  -- Optional preference
    Quantity INT NOT NULL DEFAULT 1,
    
    -- For durables: reason if user already has one
    ReplacementReason NVARCHAR(500),      -- Required if durable and user already has one
    
    -- What was actually issued
    IssuedSizeId INT FOREIGN KEY REFERENCES Sizes(SizeId),
    IssuedQuantity INT DEFAULT 0,
    
    -- Backorder tracking
    IsBackordered BIT DEFAULT 0,
    BackorderedAt DATETIME2,
    BackorderFulfilledAt DATETIME2,
    
    CONSTRAINT CK_RequestLine_Quantity CHECK (Quantity > 0)
);

CREATE INDEX IX_RequestLines_RequestId ON RequestLines(RequestId);
CREATE INDEX IX_RequestLines_IsBackordered ON RequestLines(IsBackordered);

-- =============================================
-- PERSONNEL ISSUED INVENTORY
-- =============================================

CREATE TABLE IssuedInventory (
    IssuedInventoryId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
    SizeId INT NOT NULL FOREIGN KEY REFERENCES Sizes(SizeId),
    RequestLineId INT FOREIGN KEY REFERENCES RequestLines(RequestLineId),
    Quantity INT NOT NULL DEFAULT 1,
    IssuedAt DATETIME2 DEFAULT GETUTCDATE(),
    ReturnedAt DATETIME2,
    ReturnReason NVARCHAR(500),
    ReturnCondition NVARCHAR(50),         -- Serviceable, NeedsRepair, Dispose
    
    CONSTRAINT CK_IssuedInventory_Quantity CHECK (Quantity > 0)
);

CREATE INDEX IX_IssuedInventory_UserId ON IssuedInventory(UserId);
CREATE INDEX IX_IssuedInventory_SizeId ON IssuedInventory(SizeId);
CREATE INDEX IX_IssuedInventory_Active ON IssuedInventory(UserId, ReturnedAt);

-- =============================================
-- AUDIT TRAIL
-- =============================================

CREATE TABLE AuditLog (
    AuditLogId BIGINT IDENTITY(1,1) PRIMARY KEY,
    TableName NVARCHAR(100) NOT NULL,
    RecordId INT NOT NULL,
    Action NVARCHAR(50) NOT NULL,         -- INSERT, UPDATE, DELETE
    UserId INT FOREIGN KEY REFERENCES Users(UserId),
    OldValues NVARCHAR(MAX),              -- JSON of previous values
    NewValues NVARCHAR(MAX),              -- JSON of new values
    Timestamp DATETIME2 DEFAULT GETUTCDATE(),
    IPAddress NVARCHAR(50),
    UserAgent NVARCHAR(500)
);

CREATE INDEX IX_AuditLog_TableName ON AuditLog(TableName);
CREATE INDEX IX_AuditLog_RecordId ON AuditLog(TableName, RecordId);
CREATE INDEX IX_AuditLog_Timestamp ON AuditLog(Timestamp);
CREATE INDEX IX_AuditLog_UserId ON AuditLog(UserId);

-- =============================================
-- NOTIFICATIONS
-- =============================================

CREATE TABLE NotificationTemplates (
    TemplateId INT IDENTITY(1,1) PRIMARY KEY,
    TemplateName NVARCHAR(100) NOT NULL UNIQUE,
    Subject NVARCHAR(255),
    BodyTemplate NVARCHAR(MAX),
    IsPushEnabled BIT DEFAULT 1,
    IsEmailEnabled BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETUTCDATE()
);

INSERT INTO NotificationTemplates (TemplateName, Subject, IsPushEnabled, IsEmailEnabled) VALUES
('RequestSubmitted', 'New Item Request Submitted', 1, 0),
('RequestStatusChanged', 'Your Request Status Has Changed', 1, 0),
('ReadyForPickup', 'Your Items Are Ready for Pickup', 1, 1),
('BackorderFulfilled', 'Backordered Item Now Available', 1, 1),
('LowStockAlert', 'Low Stock Alert', 1, 1),
('OrderReceived', 'Purchase Order Items Received', 1, 0);

CREATE TABLE Notifications (
    NotificationId BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
    TemplateId INT FOREIGN KEY REFERENCES NotificationTemplates(TemplateId),
    Title NVARCHAR(255) NOT NULL,
    Message NVARCHAR(1000) NOT NULL,
    RelatedTable NVARCHAR(100),
    RelatedRecordId INT,
    IsPushSent BIT DEFAULT 0,
    IsEmailSent BIT DEFAULT 0,
    IsRead BIT DEFAULT 0,
    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
    ReadAt DATETIME2
);

CREATE INDEX IX_Notifications_UserId ON Notifications(UserId);
CREATE INDEX IX_Notifications_IsRead ON Notifications(UserId, IsRead);

-- =============================================
-- PUSH NOTIFICATION SUBSCRIPTIONS
-- =============================================

CREATE TABLE PushSubscriptions (
    SubscriptionId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
    Endpoint NVARCHAR(500) NOT NULL,
    P256dh NVARCHAR(500),
    Auth NVARCHAR(500),
    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
    
    CONSTRAINT UQ_PushSubscription UNIQUE (UserId, Endpoint)
);

-- =============================================
-- INVENTORY ADJUSTMENTS (for manual counts)
-- =============================================

CREATE TABLE InventoryAdjustments (
    AdjustmentId INT IDENTITY(1,1) PRIMARY KEY,
    SizeId INT NOT NULL FOREIGN KEY REFERENCES Sizes(SizeId),
    AdjustmentType NVARCHAR(50) NOT NULL,  -- Count, Damage, Loss, Found, Transfer
    QuantityBefore INT NOT NULL,
    QuantityAfter INT NOT NULL,
    QuantityChange AS (QuantityAfter - QuantityBefore) PERSISTED,
    Reason NVARCHAR(500),
    AdjustedBy INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
    AdjustedAt DATETIME2 DEFAULT GETUTCDATE()
);

CREATE INDEX IX_InventoryAdjustments_SizeId ON InventoryAdjustments(SizeId);

-- =============================================
-- VIEWS FOR COMMON QUERIES
-- =============================================

-- Full item catalog with hierarchy
CREATE VIEW vw_ItemCatalog AS
SELECT 
    c.CategoryId,
    c.CategoryName,
    it.ItemTypeId,
    it.ItemTypeName,
    it.IsConsumable,
    it.ParLevel,
    v.VariantId,
    v.VariantName,
    v.SKU,
    v.UnitCost,
    v.Barcode,
    s.SizeId,
    s.SizeName,
    COALESCE(i.QuantityOnHand, 0) AS QuantityOnHand,
    COALESCE(i.QuantityReserved, 0) AS QuantityReserved,
    COALESCE(i.QuantityOnHand, 0) - COALESCE(i.QuantityReserved, 0) AS QuantityAvailable
FROM Categories c
JOIN ItemTypes it ON c.CategoryId = it.CategoryId
JOIN Variants v ON it.ItemTypeId = v.ItemTypeId
JOIN Sizes s ON v.VariantId = s.VariantId
LEFT JOIN Inventory i ON s.SizeId = i.SizeId
WHERE c.IsActive = 1 AND it.IsActive = 1 AND v.IsActive = 1 AND s.IsActive = 1;

-- Low stock items
CREATE VIEW vw_LowStockItems AS
SELECT 
    ic.*
FROM vw_ItemCatalog ic
JOIN ItemTypes it ON ic.ItemTypeId = it.ItemTypeId
WHERE ic.QuantityOnHand <= it.ParLevel AND it.ParLevel > 0;

-- Pending requests for warehouse queue
CREATE VIEW vw_PendingRequests AS
SELECT 
    r.RequestId,
    r.RequestDate,
    r.Status,
    r.Notes,
    u.FirstName + ' ' + u.LastName AS RequestedByName,
    u.Email AS RequestedByEmail,
    rl.RequestLineId,
    it.ItemTypeName,
    it.IsConsumable,
    s.SizeName AS RequestedSize,
    v.VariantName AS PreferredVariant,
    rl.Quantity,
    rl.ReplacementReason,
    rl.IsBackordered
FROM Requests r
JOIN Users u ON r.RequestedBy = u.UserId
JOIN RequestLines rl ON r.RequestId = rl.RequestId
JOIN ItemTypes it ON rl.ItemTypeId = it.ItemTypeId
LEFT JOIN Sizes s ON rl.RequestedSizeId = s.SizeId
LEFT JOIN Variants v ON rl.PreferredVariantId = v.VariantId
WHERE r.Status IN ('Pending', 'Backordered');

-- User's current issued inventory (durables not returned)
CREATE VIEW vw_UserIssuedInventory AS
SELECT 
    ii.UserId,
    u.FirstName + ' ' + u.LastName AS UserName,
    c.CategoryName,
    it.ItemTypeName,
    it.IsConsumable,
    v.VariantName,
    s.SizeName,
    ii.Quantity,
    ii.IssuedAt
FROM IssuedInventory ii
JOIN Users u ON ii.UserId = u.UserId
JOIN Sizes s ON ii.SizeId = s.SizeId
JOIN Variants v ON s.VariantId = v.VariantId
JOIN ItemTypes it ON v.ItemTypeId = it.ItemTypeId
JOIN Categories c ON it.CategoryId = c.CategoryId
WHERE ii.ReturnedAt IS NULL AND it.IsConsumable = 0;

-- Backorder queue
CREATE VIEW vw_BackorderQueue AS
SELECT 
    rl.RequestLineId,
    r.RequestId,
    r.RequestDate,
    u.FirstName + ' ' + u.LastName AS RequestedByName,
    it.ItemTypeName,
    s.SizeName AS RequestedSize,
    rl.Quantity,
    rl.BackorderedAt,
    COALESCE(inv.QuantityOnHand, 0) - COALESCE(inv.QuantityReserved, 0) AS CurrentAvailable
FROM RequestLines rl
JOIN Requests r ON rl.RequestId = r.RequestId
JOIN Users u ON r.RequestedBy = u.UserId
JOIN ItemTypes it ON rl.ItemTypeId = it.ItemTypeId
LEFT JOIN Sizes s ON rl.RequestedSizeId = s.SizeId
LEFT JOIN Inventory inv ON s.SizeId = inv.SizeId
WHERE rl.IsBackordered = 1 AND rl.BackorderFulfilledAt IS NULL
ORDER BY rl.BackorderedAt;
